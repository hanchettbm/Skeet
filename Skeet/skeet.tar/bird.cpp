//
//  bird.cpp
//  Skeet
//
//  Created by Baden Hanchett on 6/15/20.
//  Copyright © 2020 Baden Hanchett. All rights reserved.
//

#include "bird.h"

int Bird::hit()
{
    return numHits;
}
