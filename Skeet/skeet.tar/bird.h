//
//  bird.hpp
//  Skeet
//
//  Created by Baden Hanchett on 6/15/20.
//  Copyright © 2020 Baden Hanchett. All rights reserved.
//

#ifndef bird_h
#define bird_h

#include "flying.h"

class Bird : public Flying
{
private:
    int numHits;
    
    
public:
    Bird(Point point) : Flying()
    {
        numHits = 0;
    };
    int hit();
    
};

#endif /* bird_hpp */
